echo "import table alterinfo"
sqoop create-hive-table --connect jdbc:mysql://47.104.218.115:3306/bi --username root --password 123456 --table alertinfo --hive-table bi.alertinfo

sqoop import --connect jdbc:mysql://172.23.20.66:3306/bi --username root --password 123456 --table alertinfo --hive-import
--hive-table bi.h_alertinfo --incremental append --check-column alert_id

echo "import table cthotline"
sqoop create-hive-table --connect jdbc:mysql://47.104.218.115:3306/bi --username root --password 123456 --table cthotline --hive-table bi.cthotline

sqoop import --connect jdbc:mysql://172.23.20.66:3306/bi --username root --password 123456 --table cthotline --hive-import
--hive-table bi.cthotline --incremental append --check-column cthotline_id

echo "import table ctservice"
sqoop create-hive-table --connect jdbc:mysql://47.104.218.115:3306/bi --username root --password 123456 --table ctservice --hive-table bi.ctservice

sqoop import --connect jdbc:mysql://172.23.20.66:3306/bi --username root --password 123456 --table ctservice --hive-import
--hive-table bi.ctservice --incremental append --check-column ctservice_id

echo "import table houseresource"
sqoop create-hive-table --connect jdbc:mysql://47.104.218.115:3306/bi --username root --password 123456 --table houseresource --hive-table bi.houseresource

sqoop import --connect jdbc:mysql://172.23.20.66:3306/bi --username root --password 123456 --table houseresource --hive-import
--hive-table bi.houseresource --incremental append --check-column resource_id

echo "import table hwrepair"
sqoop create-hive-table --connect jdbc:mysql://47.104.218.115:3306/bi --username root --password 123456 --table hwrepair --hive-table bi.hwrepair

sqoop import --connect jdbc:mysql://172.23.20.66:3306/bi --username root --password 123456 --table hwrepair --hive-import
--hive-table bi.hwrepair --incremental append --check-column hwrepair_id

echo "import table lockrecords"
sqoop create-hive-table --connect jdbc:mysql://47.104.218.115:3306/bi --username root --password 123456 --table lockrecords --hive-table bi.lockrecords

sqoop import --connect jdbc:mysql://172.23.20.66:3306/bi --username root --password 123456 --table lockrecords --hive-import
--hive-table bi.lockrecords --incremental append --check-column lockrecords_id

echo "import table locksales"
sqoop create-hive-table --connect jdbc:mysql://47.104.218.115:3306/bi --username root --password 123456 --table locksales --hive-table bi.locksales

sqoop import --connect jdbc:mysql://172.23.20.66:3306/bi --username root --password 123456 --table locksales --hive-import
--hive-table bi.locksales --incremental append --check-column locksales_id

echo "import table maintance"
sqoop create-hive-table --connect jdbc:mysql://47.104.218.115:3306/bi --username root --password 123456 --table maintance --hive-table bi.maintance

sqoop import --connect jdbc:mysql://172.23.20.66:3306/bi --username root --password 123456 --table maintance --hive-import
--hive-table bi.maintance --incremental append --check-column maintance_id

echo "import table room"
sqoop create-hive-table --connect jdbc:mysql://47.104.218.115:3306/bi --username root --password 123456 --table room --hive-table bi.room

sqoop import --connect jdbc:mysql://172.23.20.66:3306/bi --username root --password 123456 --table room --hive-import
--hive-table bi.room --incremental append --check-column room_id

echo "import table roomservice"
sqoop create-hive-table --connect jdbc:mysql://47.104.218.115:3306/bi --username root --password 123456 --table roomservice --hive-table bi.roomservice

sqoop import --connect jdbc:mysql://172.23.20.66:3306/bi --username root --password 123456 --table roomservice --hive-import
--hive-table bi.roomservice --incremental append --check-column roomservice_id

echo "import table user"
sqoop create-hive-table --connect jdbc:mysql://47.104.218.115:3306/bi --username root --password 123456 --table user --hive-table bi.user

sqoop import --connect jdbc:mysql://172.23.20.66:3306/bi --username root --password 123456 --table user --hive-import
--hive-table bi.user --incremental append --check-column user_id

