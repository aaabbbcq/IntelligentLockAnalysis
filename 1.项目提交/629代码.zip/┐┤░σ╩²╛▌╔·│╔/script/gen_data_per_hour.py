# -*- coding: utf-8 -*-
import numpy as np
import datetime
from mysql import mysql
import string
import random

USER_NUM = 200
ROOM_NUM = 100
SERVICE_NUM = 1000
MAINTANCE_NUM = 1000
ALTER_NUM = 1000
SERVICE_TYPE = [0, 1, 2, 3, 4]
BATTERY = [0, 100]
VOICE = [1, 10]
MAINTANCE_STATU = [0, 1]
ALTER_STATU = [0, 1, 2, 3, 4]
ALTER_TYPE = [0, 1, 2]
WIFI = [-150, 50]
PRICE = [100, 1000]
GPRS_ERROR = [0, 1, 2, 3, 4, 5, 6, 7, 99]
GPRS = [0, 31]
OPEN_TYPE = [0, 1, 2, 3, 4, 5, 6, 7]
CITY = ['北京', '天津', '上海', '重庆', '广州', '成都', '石家庄', '济南',
        '杭州', '南京', '太原', '沈阳', '福州', '武汉', '长沙','长春',
        '哈尔滨', '呼和浩特', '合肥', '南昌',  '郑州','南宁','海口',
        '贵阳', '昆明', '西安', '兰州', '西宁','拉萨', '银川', '乌鲁木齐']

PIC = ['http://47.104.195.116:8788/r/img/{}.png'.format(x)
       for x in ['20180613150501', '20180613150535',
                 '20180613150541', '20180613150546',
                 '20180613150552', '20180613150558']]

def random_room_data(conn, table, room_num, citys, pics):

    weights = sorted(np.random.dirichlet(np.ones(len(citys)), size=1)[0],
                     reverse=True)
    # start = conn.get_table_max_len(table, 'room_id')
    for id in range(room_num):
    # for id in range(1, room_num + 1):
        city = np.random.choice(citys, p=weights)
        type = np.random.randint(3)
        pic = random.choice(pics)
        conn.insert(table, {'city': city, 'type': type, 'pic':pic})

def random_lock_data(conn, table, dict, room_num, user_num, hour=1):
    max_room_num = conn.get_table_max_len('room', 'room_id')
    if max_room_num > room_num:
        room_num = max_room_num
    max_user_num = conn.get_table_max_len('user', 'user_id')
    if max_user_num > user_num:
        user_num = max_user_num
    time = datetime.datetime.now()
    id = 1
    for second in range(36000 * hour):
        if random.random() < 0.5:
            continue
        lockrecord_id = id
        room_id = random.randint(1, room_num)
        user_id = random.randint(1, user_num)
        battery_1_v = random.randint(dict['battery'][0], dict['battery'][1])
        battery_1 = random.randint(dict['battery'][0], dict['battery'][1])
        battery_2_v = random.randint(dict['battery'][0], dict['battery'][1])
        battery_2 = random.randint(dict['battery'][0], dict['battery'][1])
        magnetic = random.choice([0, 1])
        lock = random.choice([0, 1])
        silence = random.choice([0, 1])
        voice = random.randint(dict['voice'][0], dict['voice'][1])
        wifi = random.randint(dict['wifi'][0], dict['wifi'][1])
        gprs_list = list(range(dict['gprs'][0], dict['gprs'][1]+1))
        gprs_list.append(99)
        gprs = random.choice(gprs_list)
        gprs_error = random.choice(dict['gprs_error'])
        online = random.choice([0, 1])
        open_type = random.choice(dict['open_type'])
        open_time = time + datetime.timedelta(seconds=second / 10)

        conn.insert(table, {'room_id': room_id, 'user_id': user_id,
                            'battery_1_v': battery_1_v, 'battery_1': battery_1,
                            'battery_2_v': battery_2_v, 'battery_2': battery_2,
                            'magnetic': magnetic, 'lockinfo': lock,
                            'silence': silence, 'voice': voice, 'wifi': wifi,
                            'gprs': gprs, 'gprs_error': gprs_error,
                            'onlinestate': online, 'opentype': open_type,
                            'opentime': open_time})

        id += 1

def random_user_data(conn, table, user_num):

    mobile_begin_seed = ['134', '135', '136', '137', '138', '139', '150', '151',
                         '152', '157', '158', '159', '182', '183', '187', '188',
                         '130', '131', '132', '155', '156', '175', '185', '186',
                         '133', '153', '177', '180', '181', '189']
    mobile_seed = string.digits
    username_seed = string.digits + string.ascii_letters
    minlength = 4
    maxlength = 16
    # start = conn.get_table_max_len(table, 'user_id')
    for id in range(user_num):
    # for id in range(1, user_num+1):
        mobile = random.choice(mobile_begin_seed) + ''.join(
            random.choice(mobile_seed) for m in range(8))
        user_name = ''.join(random.choice(username_seed) for u in
                           range(random.randint(minlength, maxlength)))

        conn.insert(table, {'username': user_name, 'user_tel': mobile})

def random_room_service_data(conn, table, user_num, service_type, price_para,
                             service_num=None, hour=None):
    max_user_num = conn.get_table_max_len('user', 'user_id')
    if max_user_num > user_num:
        user_num = max_user_num
    time = datetime.datetime.now()
    if hour:
        id = 1
        for second in range(3600 * hour):
            if random.random() < 0.5:
                continue
            price = random.randint(price_para[0], price_para[1])
            type = random.choice(service_type)
            user_id = random.randint(1, user_num)
            service_time = time + datetime.timedelta(seconds=second)

            conn.insert(table, {'user_id': user_id,
                                'roomservice_type': type,
                                'roomservice_price': price,
                                'roomservice_time': service_time})

            id += 1
    if service_num:
        for id in range(1, service_num+1):
            price = random.randint(price_para[0], price_para[1])
            type = random.choice(service_type)
            user_id = random.randint(1, user_num)
            service_time = time + datetime.timedelta(seconds=random.randint(0, 60))

            conn.insert(table, {'user_id': user_id,
                                'roomservice_type': type,
                                'roomservice_price': price,
                                'roomservice_time': service_time})

def random_maintance_data(conn, table, room_num ,maintance_statu,
                          maintance_num=None, hour=None):
    max_room_num = conn.get_table_max_len('room', 'room_id')
    if max_room_num > room_num:
        room_num = max_room_num
    time = datetime.datetime.now()
    if hour:
        id = 1
        for second in range(3600 * hour):
            if random.random() < 0.5:
                continue
            room_id = random.randint(1, room_num + 1)
            statu = random.choice(maintance_statu)
            maintance_time = time + datetime.timedelta(seconds=second)

            conn.insert(table, {'room_id': room_id,
                                'maintance_statu': statu,
                                'maintance_time': maintance_time})
            id += 1

    if maintance_num:
        for id in range(1, maintance_num+1):
            room_id = random.randint(1, room_num+1)
            statu = random.choice(maintance_statu)
            maintance_time = time + datetime.timedelta(seconds=random.randint(1, 60))

            conn.insert(table, {'room_id': room_id,
                                'maintance_statu': statu,
                                'maintance_time': maintance_time})

def random_alertinfo_data(conn, table, room_num, alter_statu, alter_type,
                          alter_num=None, hour=None):
    max_room_num = conn.get_table_max_len('room', 'room_id')
    if max_room_num > room_num:
        room_num = max_room_num
    time = datetime.datetime.now()
    if hour:
        id = 1
        for second in range(3600 * hour):
            if random.random() < 0.5:
                continue
            room_id = random.randint(1, room_num + 1)
            statu = random.choice(alter_statu)
            type = random.choice(alter_type)
            alter_time = time + datetime.timedelta(seconds=second)

            conn.insert(table, {'room_id': room_id, 'alert_type': type,
                                'alert_status': statu, 'alert_time': alter_time})

            id += 1

    if alter_num:
        for id in range(1, alter_num+1):
            room_id = random.randint(1, room_num+1)
            statu = random.choice(alter_statu)
            type = random.choice(alter_type)
            alter_time = time + datetime.timedelta(seconds=random.randint(1, 60))

            conn.insert(table, {'room_id': room_id, 'alert_type':type,
                                'alert_status': statu, 'alert_time': alter_time})

if __name__ == '__main__':
    kw = {'battery': BATTERY, 'voice': VOICE, 'gprs_error': GPRS_ERROR,
          'gprs': GPRS, 'wifi': WIFI, 'open_type': OPEN_TYPE}
    db = mysql('47.104.218.115', 3306, 'root', '123456', 'bi', 'utf8')
    # db = mysql('localhost', 3306, 'root', '123456', 'test', 'utf8')
    print('connect success!')

    random_user_data(db, 'user', USER_NUM)
    print('user done!')

    random_room_data(db, 'room', ROOM_NUM, CITY, PIC)
    print('room done!')

    random_lock_data(db, 'lockrecords', kw, ROOM_NUM, USER_NUM)
    print('lockrecords done!')

    random_room_service_data(db, 'roomservice',  USER_NUM,
                             SERVICE_TYPE, PRICE, hour=1)
    print('roomservice done!')

    random_maintance_data(db, 'maintance', ROOM_NUM,
                          MAINTANCE_STATU, hour=1)
    print('maintance done!')

    random_alertinfo_data(db, 'alertinfo', ROOM_NUM, ALTER_STATU,
                          ALTER_TYPE, hour=1)
    print('alertinfo done!')
