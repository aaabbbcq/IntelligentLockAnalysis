import pymysql

class mysql(object):

    def __init__(self, host, port, user, password, database, charset):
        self.__host = host
        self.__port = port
        self.__user = user
        self.__password = password
        self.__database = database
        self.__charset = charset
        self.cursor = None
        self.db = None
        self.__connect__()

    def __connect__(self):
        self.db = pymysql.connect(host=self.__host,
                                  port=self.__port,
                                  user=self.__user,
                                  password=self.__password,
                                  db=self.__database,
                                  charset=self.__charset)

        self.cursor = self.db.cursor()

    def execute(self, sql, values=None):
        if values:
            self.cursor.execute(sql, values)
        else:
            self.cursor.execute(sql)
        self.db.commit()

    def close(self):
        self.cursor.close()

    def insert(self, table, value_dict):
        keys = ['`'+ x + '`' for x in value_dict.keys()]
        sql = "INSERT INTO `{}` ({}) VALUES" \
              " ({})".format(table,
                             ','.join(keys),
                             ','.join(['%s'] * len(value_dict)))
        values = [str(x) for x in value_dict.values()]
        self.execute(sql, values)

    def clean_table(self, table):
        sql = "truncate table {};".format(table)
        self.execute(sql)

    def clean_tables(self, table_name_list):
        for table in table_name_list:
            self.clean_table(table)

    def get_last_record(self, table, primary_key, condition=None):
        if condition:
            sql = "select * from {} where {} order by {} DESC limit 1".format(table, condition, primary_key)
        else:
            sql = "select * from {} order by {} DESC limit 1".format(table,
                                                                     primary_key)
        self.cursor.execute(sql)
        last_record = self.cursor.fetchone()

        sql = "select COLUMN_NAME from information_schema.COLUMNS " \
              "where table_name = '{}';".format(table)
        self.cursor.execute(sql)
        columns = self.cursor.fetchall()

        return {item[1][0]:item[0] for item in zip(last_record, columns)}

    def get_table_max_len(self, table, columns):
        sql = 'select max({}) from {}'.format(columns, table)
        self.cursor.execute(sql)
        max_len = self.cursor.fetchone()
        self.db.commit()
        return max_len[0]
