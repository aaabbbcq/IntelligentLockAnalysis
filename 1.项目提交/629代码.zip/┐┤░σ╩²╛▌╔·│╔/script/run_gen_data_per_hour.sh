python3=/root/anaconda3/bin/python
filename=/usr/local/tengleitest
$python3 $filename/gen_data_per_hour.py