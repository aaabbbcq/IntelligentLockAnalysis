import numpy as np
import datetime
from mysql import mysql

APT_NAME = "蘑菇公寓,小米公寓,自如公寓,青年公寓,青稞公寓,魔方公寓," \
           "壹栈公寓,魔飞公寓".split(',')

def random_data(apt_name, room_num, time):
    apartment_name = np.random.choice(apt_name)
    room_id = np.random.randint(1, room_num)
    is_order = np.random.choice([0, 1], p=[0.3, 0.7])
    if is_order == 0:
        is_look = 1
    else:
        is_look = np.random.choice([0, 1], p=[0.3, 0.7])

    look_time = time
    # look_time = time - datetime.timedelta(
    #     minutes=np.random.randint(5, 10), seconds=np.random.randint(60)
    # )
    if look_time.hour not in range(8, 19):
        look_time = look_time.replace(hour=np.random.choice(range(8, 19)))

    order_time = look_time - datetime.timedelta(
        hours=np.random.randint(10, 40), minutes=np.random.randint(60),
        seconds=np.random.randint(60)
    )
    if order_time.hour in range(7):
        order_time = order_time.replace(hour=np.random.choice(range(7, 24)))

    if order_time > look_time:
        look_time, order_time = order_time, look_time

    look_room_money = np.random.randint(500, 2000)
    sum_money = int(look_room_money * 0.3)

    if is_order == 1 and is_look == 1:
        data = {'apt_name': apartment_name, 'room_id': room_id,
                'is_order': is_order, 'is_look': is_look,
                'order_time': order_time, 'look_time': look_time,
                'look_room_money': look_room_money, 'sum_money': sum_money}
        return data

    if is_order == 1 and is_look == 0:
        data = {'apt_name': apartment_name, 'room_id': room_id,
                'is_order': is_order, 'is_look': is_look,
                'order_time': order_time, 'look_room_money': look_room_money}
        return data

    if is_order == 0 and is_look == 1:
        data = {'apt_name': apartment_name, 'room_id': room_id,
                'is_order': is_order, 'is_look': is_look,
                'look_time': look_time, 'sum_money': sum_money}
        return data

def random_house_resource(conn, table, apt_name, hour=True, data_num=None):
    max_room_num = conn.get_table_max_len('room', 'room_id')

    if hour:
        time = datetime.datetime.now()
        data_num = np.random.randint(30, 50)
        for second in range(3600):
            if np.random.random() < data_num / 3600:
                insert_data = random_data(apt_name,
                                          max_room_num,
                                          time+datetime.timedelta(seconds=second))
                conn.insert(table, insert_data)

    else:
        conn.clean_table(table)
        time = datetime.datetime.now()
        for i in range(data_num):
            insert_data = random_data(apt_name, max_room_num, time)
            conn.insert(table, insert_data)
            time = time - datetime.timedelta(minutes=np.random.randint(3, 7))

db = mysql('47.104.218.115', 3306, 'root', '123456', 'bi', 'utf8')
# db = mysql('localhost', 3306, 'root', '123456', 'test', 'utf8')
random_house_resource(db, 'houseresource', APT_NAME)
# db = mysql('localhost', 3306, 'root', '123456', 'test', 'utf8')
# random_house_resource(db, 'houseresource', APT_NAME, hour=False, data_num=50000)