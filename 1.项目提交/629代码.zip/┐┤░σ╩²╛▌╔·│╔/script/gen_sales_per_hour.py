import datetime
import numpy as np
from mysql import mysql

TYPE = ['CT-AT10', 'CT-BRFPDA-I4', 'CT-Q305/Q305Z', 'CT-C10F300',
        'CT-H1-RFPDA-R9', 'CT-H2-RFPDA-Z', 'CT-ZNMS12LM-R1',
        'CT-FIND-X1', 'CT-SHS-DP728', 'CT-DSL-C05']

NAME = ['标配版', '旗舰版', '豪华版', '经典版', '精英版',
        '尊享版', '创新版', '至尊版', '普通版', '科技版']

PRICE = [499, 899, 799, 599, 699, 859,
         999, 1099, 1599, 559, 1299]

AREA = ['北京', '天津', '上海', '重庆', '广州', '成都', '石家庄','济南',
        '杭州', '南京', '太原', '沈阳', '福州', '武汉', '长沙','长春',
        '哈尔滨', '呼和浩特', '合肥', '南昌',  '郑州','南宁','海口',
        '贵阳', '昆明', '西安', '兰州', '西宁','拉萨', '银川', '乌鲁木齐']

BRANCH = {1: ["北京", "武汉", "乌鲁木齐", "郑州", "银川", "呼和浩特"],
          2: ["重庆", "成都", "拉萨", "长沙", "广州", "福州", "南京", "杭州"],
          3: ["南宁", "合肥", "海口", "南昌", "贵阳"],
          4: ["沈阳", "石家庄", "太原", "哈尔滨", "西安"],
          5: ["天津", "济南", "长春", "上海", "西宁", "兰州", "昆明"]}

DAY_GAP = 180
DATA_NUMBER = 50000

def random_sales(conn, table, t_n_p, area, branch_dict):
    max_user_num = conn.get_table_max_len('user', 'user_id')
    # start_time = datetime.datetime.now()
    start_time = conn.get_last_record(
        'locksales', 'locksales_id', condition='sale_time is not null'
    )['sale_time']
    data_num = np.random.randint(70, 80)

    for second in range(3600):
        if np.random.random() < data_num / 3600:
            saled = np.random.choice([0, 1], p=[0.1, 0.9])
            if saled == 0:
                conn.insert(table, {'saled': saled})
            else:
                user_id = np.random.randint(1, max_user_num)
                sale_time = start_time + datetime.timedelta(seconds=second)
                lock_type = t_n_p[np.random.randint(len(t_n_p))][0]
                lock_price = t_n_p[np.random.randint(len(t_n_p))][2]
                user_area = np.random.choice(area)
                lock_name = t_n_p[np.random.randint(len(t_n_p))][1]
                branch = [i for i in range(1, 6)
                          if user_area in branch_dict[i]][0]
                conn.insert(table, {'user_id': user_id, 'sale_time': sale_time,
                                    'lock_type': lock_type, 'saled': saled,
                                    'lock_price': lock_price, 'branch': branch,
                                    'lock_price': lock_price,
                                    'user_area': user_area,
                                    'lock_name': lock_name})

db = mysql('47.104.218.115', 3306, 'root', '123456', 'bi', 'utf8')
random_sales(db, 'locksales', list(zip(TYPE, NAME, PRICE)), AREA, BRANCH)