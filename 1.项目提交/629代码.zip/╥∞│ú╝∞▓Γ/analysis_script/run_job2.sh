filename=/usr/local/chuangtingBigData

python2 $filename/analysis_abnormal_gprs_battery.py

echo “Python script starting...”
