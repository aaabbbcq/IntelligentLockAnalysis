#!/bin/sh  
filename=/usr/local/chuangtingBigData

python2 $filename/find_mean_std_impyla.py

echo ��Python script starting...��